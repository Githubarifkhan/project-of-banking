package com.bank.repository;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.bank.domain.Bank;
import com.bank.domain.Customer;
@Repository
public class CustomerDaoImpl implements CustomerDao{ 
	@PersistenceContext
	private EntityManager em;
	@Transactional
		@Override
		public Customer save(Customer customer) {
			em.persist(customer);
			return customer;
			// TODO Auto-generated method stub
			
		}

	
		public Bank addBank(Bank bank) {
			em.persist(bank);	
			return bank;
		}

		

	}

