package com.bank.repository;

import java.util.Set;

import com.bank.domain.Transaction;

public interface TransactionDao {
	Transaction findTransactionById(int transactionId);
	Set<Transaction> viewAllTransactions() ;
	void transferFunds(int fromAccNo, int toAccNo, float transferAmt);
    void  depositFunds(int accNo, int depositAmt);

}
