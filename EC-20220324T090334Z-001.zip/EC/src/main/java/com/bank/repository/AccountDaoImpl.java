package com.bank.repository;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.bank.domain.Account;
import com.bank.domain.Customer;

@Repository
public class AccountDaoImpl implements AccountDao{
	
		@PersistenceContext
		EntityManager em;

		
		@Transactional
		public Account addOrUpdateAccount(Account account) {

			Account a1 = em.merge(account);

			return a1;
		}

		public Account findAccountByNo(long accountNO) {
			return em.find(Account.class, accountNO);
		}

		public Set<Account> viewAllAccounts() {
			String jpql = "select a from Account1 a";
			// Query query=em.createQuery(jpql);
			TypedQuery<Account> query = em.createQuery(jpql, Account.class);
			return new HashSet<Account>(query.getResultList());
		}

		@Transactional
		public List<Account> viewAllaccountsInAnCustomerId(int customerId) {
			Customer customer = em.find(Customer.class, customerId);
			return customer.getAccount();
		}	

}