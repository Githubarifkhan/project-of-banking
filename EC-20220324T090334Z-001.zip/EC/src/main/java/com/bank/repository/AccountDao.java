package com.bank.repository;

import java.util.List;
import java.util.Set;

import com.bank.domain.Account;

public interface AccountDao {
	Account addOrUpdateAccount(Account account);
	Account findAccountByNo(long accountNO);
	Set<Account> viewAllAccounts();
	List<Account> viewAllaccountsInAnCustomerId(int customerId);
	

}
