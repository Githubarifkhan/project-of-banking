package com.bank.repository;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.bank.domain.Account;
import com.bank.domain.Transaction;
@Component
@Repository
public class TransactionDaoImpl implements TransactionDao{
	@PersistenceContext
   private  EntityManager em;
   
   
 public Transaction findTransactionById(int transactionId) {
  		return em.find(Transaction.class, transactionId);
  	}

  	public Set<Transaction> viewAllTransactions() {
  		String jpql = "select t from Transaction t ";
  		TypedQuery<Transaction> query = em.createNamedQuery(jpql, Transaction.class);
  		return new HashSet<Transaction>(query.getResultList());
  	}

public void transferFunds(int fromAccNo, int toAccNo, float transferAmt) {
	Account c = em.find(Account.class, fromAccNo);
	Account c1 = em.find(Account.class, toAccNo);
	if(c != null && c1 != null)
	if(c.getAccNo() == fromAccNo || c1.getAccNo() == toAccNo)
	if(c.getBalAmt() > transferAmt && transferAmt > 0) {
	System.out.println("\nInitial Balance for Account Number : " + fromAccNo + " is : Rs." + c.getBalAmt());
	System.out.println("Initial Balance for Account Number : " + toAccNo + " is : Rs." + c1.getBalAmt() + "\n");
	c1.setBalAmt(c1.getBalAmt() + transferAmt);
	c.setBalAmt(c.getBalAmt() - transferAmt );
	System.out.println("Transferred Rs." + transferAmt + "\nto Account Number : " + toAccNo + "\nfrom Account Number : " + fromAccNo + "\n");
	System.out.println("Updated Balance for Account Number : " + fromAccNo +" is Rs." + c.getBalAmt());
	System.out.println("Updated Balance for Account Number : " + toAccNo +" is Rs." + c1.getBalAmt());
	System.out.println("Transfer Successful!");
	}
	else
	System.out.println("Insufficient Balance to transfer!");
	else
	System.out.println("Invalid Account Numbers!");
	else
	System.out.println("Invalid Accounts!");
}	

public void depositFunds(int accNo, int depositAmt) {
	Account c = em.find(Account.class, accNo);
	if(c != null) {
	if(depositAmt > 0) {
	System.out.println("Initial Balance for Account Number : " + accNo + " is : Rs." + c.getBalAmt());
	c.setBalAmt(c.getBalAmt() + depositAmt);
	System.out.println("Added Rs." + depositAmt + "to Account Number : " + accNo);
	System.out.println("Updated Balance : Rs." + c.getBalAmt());
	em.getTransaction().commit();
	System.out.println("Deposition Successful!");
	em.close();
	}
	else
	System.out.println("Invalid Amount!");
	}
	else
	System.out.println("Invalid Account Number!");
	}
}
