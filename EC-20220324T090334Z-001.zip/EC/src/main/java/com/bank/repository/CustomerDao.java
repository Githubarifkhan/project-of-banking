package com.bank.repository;

import java.util.List;
import java.util.Set;

import com.bank.domain.Account;
import com.bank.domain.Bank;
import com.bank.domain.Customer;

public interface CustomerDao {

	Customer save(Customer customer);


	Bank addBank(Bank bank);

	


	

	
	
}
