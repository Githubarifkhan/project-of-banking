package com.bank.domain;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name="Transaction")
public class Transaction {
	@Id
	private int transactionId;
	private float depositedAmt;
	private float withdrawnAmt;
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate depositedDate;
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate withdrawnDate;
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int transactionId, float depositedAmt, float withdrawnAmt, LocalDate depositedDate,
			LocalDate withdrawnDate) {
		super();
		this.transactionId = transactionId;
		this.depositedAmt = depositedAmt;
		this.withdrawnAmt = withdrawnAmt;
		this.depositedDate = depositedDate;
		this.withdrawnDate = withdrawnDate;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public float getDepositedAmt() {
		return depositedAmt;
	}
	public void setDepositedAmt(float depositedAmt) {
		this.depositedAmt = depositedAmt;
	}
	public float getWithdrawnAmt() {
		return withdrawnAmt;
	}
	public void setWithdrawnAmt(float withdrawnAmt) {
		this.withdrawnAmt = withdrawnAmt;
	}
	public LocalDate getDepositedDate() {
		return depositedDate;
	}
	public void setDepositedDate(LocalDate depositedDate) {
		this.depositedDate = depositedDate;
	}
	public LocalDate getWithdrawnDate() {
		return withdrawnDate;
	}
	public void setWithdrawnDate(LocalDate withdrawnDate) {
		this.withdrawnDate = withdrawnDate;
	}

	

}
