package com.bank.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Bank")
public class Bank {
	@Id
	private String ifscCode;
	private String bankName;
	private String branchName;
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,mappedBy="bank")
	private List<Customer> list;
	
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bank(String ifscCode, String bankName, String branchName) {
		super();
		this.ifscCode = ifscCode;
		this.bankName = bankName;
		this.branchName = branchName;
	}
	public List<Customer> getList() {
		return list;
	}
	public void setList(List<Customer> list) {
		this.list = list;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String string) {
		this.ifscCode = string;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	@Override
	public String toString() {
		return "Bank [ifscCode=" + ifscCode + ", bankName=" + bankName + ", branchName=" + branchName + "]";
	}
	

}
