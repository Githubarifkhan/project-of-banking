package com.bank.domain;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Customer")
public class Customer {
	@Id
	@GeneratedValue
	private int custId;
	private String custName;
	private String gender;
	private String address;
	private long phoneNo;
	
	@ManyToOne
	@JoinColumn(name="IFSC_CODE")
	private Bank bank;
	@OneToMany(fetch=FetchType.EAGER,cascade=CascadeType.PERSIST)
	@JoinColumn(name="accNo")
	private List<Account> account;
	
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", gender=" + gender + ", address=" + address
				+ ", phoneNo=" + phoneNo + "]";
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int custId, String custName, String gender, String address, long phoneNo) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.gender = gender;
		this.address = address;
		this.phoneNo = phoneNo;
	}
	public List<Account> getAccount() {
		return account;
	}
	public void setAccount(List<Account> account) {
		this.account = account;
	}
	public Bank getBank() {
		return bank;
	}
	public void setBank(Bank bank) {
		this.bank = bank;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	

}
