package com.bank.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bank.domain.Account;
import com.bank.domain.Bank;
import com.bank.domain.Customer;
import com.bank.domain.Transaction;
import com.bank.repository.CustomerDao;
import com.bank.service.CustomerService;

@CrossOrigin(origins = "*",
methods = {RequestMethod.GET,RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT})
@RestController
public class CustomerAPI {
	@Autowired
	private CustomerService customerdao;
	
	@PostMapping("/savecustomer")
    public String insertCustomer(@RequestBody Customer customer) {
		customerdao.save(customer);
    	return "customers details added";
    }
	@PostMapping("/savebank")
    public String insertBank(@RequestBody Bank bank) {
	customerdao.addBank(bank);
    	return "added Bank";
    }
	@GetMapping("/findaccount/{accountNo}")
	public Account findAccountByNo(long accountNo) {
		return customerdao.findAccountByNo(accountNo);
	}

	@GetMapping("/viewallaccounts")
	public Set<Account> viewAllAccounts() {
		return customerdao.viewAllAccounts();
	}
    
	public void depositFunds(int accNo, int depositAmt) {
	
	}
	public void transferFunds(int fromAccNo, int toAccNo, float transferAmt) {
		
	}
	@GetMapping("/findTransaction/{transactionId}")
	public Transaction findTransactionById(int transactionId) {
		return customerdao.findTransactionById(transactionId);
	}
	@GetMapping("/viewalltransactions")
	public Set<Transaction> viewAllTransactions(){
		return customerdao.viewAllTransactions();
	}
	
}