package com.bank.service;

import java.util.List;
import java.util.Set;

import com.bank.domain.Account;
import com.bank.domain.Bank;
import com.bank.domain.Customer;
import com.bank.domain.Transaction;

public interface CustomerService {
	Customer save(Customer customer);

	
	Bank addBank(Bank bank);


	Account findAccountByNo(long accountNo);
	
	Set<Account> viewAllAccounts();

	List<Account> viewAllaccountsInAnCustomerId(int customerId);

	Transaction findTransactionById(int transactionId);

	Set<Transaction> viewAllTransactions();
	}
