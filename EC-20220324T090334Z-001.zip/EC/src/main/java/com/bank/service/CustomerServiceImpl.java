package com.bank.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.domain.Account;
import com.bank.domain.Bank;
import com.bank.domain.Customer;
import com.bank.domain.Transaction;
import com.bank.repository.AccountDao;
import com.bank.repository.CustomerDao;
import com.bank.repository.TransactionDao;
@Service
public class CustomerServiceImpl implements CustomerService {
		@Autowired
		CustomerDao dao;

		@Autowired
		AccountDao accdao;
		
		@Autowired
		TransactionDao tdao;


		@Override
		public Account findAccountByNo(long accountNo) {

			return accdao.findAccountByNo(accountNo);
		}

		@Override
		public Set<Account> viewAllAccounts() {

			return accdao.viewAllAccounts();
		}

		@Override
		public List<Account> viewAllaccountsInAnCustomerId(int customerId) {

			return accdao.viewAllaccountsInAnCustomerId(customerId);
		}
		
		@Override
		public Transaction findTransactionById(int transactionId) {

			return tdao.findTransactionById(transactionId);
		}

		@Override
		public Set<Transaction> viewAllTransactions() {

			return tdao.viewAllTransactions();
		}

		@Override
		public Customer save(Customer customer) {
			return dao.save(customer);
		
			// TODO Auto-generated method stub
			
		}

		@Override
		public Bank addBank(Bank bank) {
			return dao.addBank(bank);
			// TODO Auto-generated method stub
			
		}

	

    
}